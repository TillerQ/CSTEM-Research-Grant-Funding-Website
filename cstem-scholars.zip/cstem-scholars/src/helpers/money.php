<?php

function usd($amount)
{
    return '$' . number_format($amount, 2);
}
